import { N, _ } from "../chunks/2.DuavqcSm.js";
export {
  N as component,
  _ as universal
};
